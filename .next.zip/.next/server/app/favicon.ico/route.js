var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[root-of-the-server]__1b2r67z._.js")
R.c("server/chunks/[root-of-the-server]__163w3q6._.js")
R.c("server/chunks/node_modules_next_1zdbrne._.js")
R.c("server/chunks/_next-internal_server_app_favicon_ico_route_actions_0g2jjls.js")
R.m(27413)
module.exports=R.m(27413).exports
