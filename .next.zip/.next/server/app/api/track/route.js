var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/track/route.js")
R.c("server/chunks/[root-of-the-server]__0b2pqwx._.js")
R.c("server/chunks/[root-of-the-server]__163w3q6._.js")
R.c("server/chunks/node_modules_next_1_14bcs._.js")
R.c("server/chunks/_next-internal_server_app_api_track_route_actions_0eauih4.js")
R.m(73149)
module.exports=R.m(73149).exports
