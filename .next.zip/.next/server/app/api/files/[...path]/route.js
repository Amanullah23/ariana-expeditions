var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/files/[...path]/route.js")
R.c("server/chunks/[root-of-the-server]__1dzg0yn._.js")
R.c("server/chunks/[root-of-the-server]__163w3q6._.js")
R.c("server/chunks/node_modules_next_1zdbrne._.js")
R.c("server/chunks/_next-internal_server_app_api_files_[___path]_route_actions_1p-_ns8.js")
R.m(11284)
module.exports=R.m(11284).exports
