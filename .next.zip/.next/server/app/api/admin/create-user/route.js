var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/create-user/route.js")
R.c("server/chunks/[root-of-the-server]__00hevp1._.js")
R.c("server/chunks/node_modules_next_1_14bcs._.js")
R.c("server/chunks/[root-of-the-server]__163w3q6._.js")
R.c("server/chunks/node_modules_next_1zdbrne._.js")
R.c("server/chunks/_189rduj._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_create-user_route_actions_1vt9_r2.js")
R.m(60624)
module.exports=R.m(60624).exports
