var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/passport/route.js")
R.c("server/chunks/[root-of-the-server]__0d4ixrg._.js")
R.c("server/chunks/node_modules_next_1_14bcs._.js")
R.c("server/chunks/node_modules_next_1zdbrne._.js")
R.c("server/chunks/[root-of-the-server]__163w3q6._.js")
R.c("server/chunks/_189rduj._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_passport_route_actions_0k-34bu.js")
R.m(18878)
module.exports=R.m(18878).exports
