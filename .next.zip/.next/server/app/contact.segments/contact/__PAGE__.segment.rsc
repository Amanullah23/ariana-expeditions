1:"$Sreact.fragment"
2:I[57218,["/_next/static/chunks/3fmnccby_s-fi.js","/_next/static/chunks/2s5mxlqtxv6vq.js","/_next/static/chunks/14mrh2-p_w84d.js","/_next/static/chunks/1wc5h3odzm7hr.js","/_next/static/chunks/1-xwx4fye3mkt.js"],"default"]
3:I[97367,["/_next/static/chunks/3fmnccby_s-fi.js","/_next/static/chunks/2s5mxlqtxv6vq.js","/_next/static/chunks/14mrh2-p_w84d.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":[["$","$L2",null,{}],[["$","script","script-0",{"src":"/_next/static/chunks/1wc5h3odzm7hr.js","async":true}],["$","script","script-1",{"src":"/_next/static/chunks/1-xwx4fye3mkt.js","async":true}]],["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"PWMbJtbzoitQKYN06SJZu"}
5:null
