:HL["/_next/static/chunks/2xr0yvyf618q9.css","style"]
:HC["/",""]
0:{"tree":{"name":"","param":null,"prefetchHints":16,"slots":{"children":{"name":"privacy","param":null,"prefetchHints":0,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":0,"slots":null}}}}},"staleTime":300,"buildId":"PWMbJtbzoitQKYN06SJZu"}
