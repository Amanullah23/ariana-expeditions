var R=require("../../chunks/[turbopack]_runtime.js")("server/app/robots.txt/route.js")
R.c("server/chunks/[root-of-the-server]__15ea8le._.js")
R.c("server/chunks/[root-of-the-server]__163w3q6._.js")
R.c("server/chunks/node_modules_next_1zdbrne._.js")
R.c("server/chunks/_next-internal_server_app_robots_txt_route_actions_15vc_89.js")
R.m(71554)
module.exports=R.m(71554).exports
