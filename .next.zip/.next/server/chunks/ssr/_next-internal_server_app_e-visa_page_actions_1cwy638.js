module.exports=[73016,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_e-visa_page_actions_1cwy638.js.map