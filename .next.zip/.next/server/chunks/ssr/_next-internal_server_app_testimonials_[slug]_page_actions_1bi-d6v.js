module.exports=[70238,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_testimonials_%5Bslug%5D_page_actions_1bi-d6v.js.map