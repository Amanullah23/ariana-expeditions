module.exports=[5795,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_places_theme_%5Bslug%5D_page_actions_0zlory1.js.map