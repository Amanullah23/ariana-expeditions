globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/PWMbJtbzoitQKYN06SJZu/_buildManifest.js",
    "static/PWMbJtbzoitQKYN06SJZu/_ssgManifest.js",
    "static/PWMbJtbzoitQKYN06SJZu/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/2t6mfabd9hnf2.js",
    "static/chunks/0245a4ypel7xx.js",
    "static/chunks/2nz2tenwrxqnx.js",
    "static/chunks/31iarpvmym1z2.js",
    "static/chunks/0_3n48q_v7q76.js",
    "static/chunks/turbopack-3ek5gmh2a01k-.js"
  ]
};
