var R=require("./chunks/[turbopack]_runtime.js")("server/middleware.js")
R.c("server/chunks/[externals]__08y5le-._.js")
R.c("server/chunks/[root-of-the-server]__0jmlr_0._.js")
R.m(5064)
module.exports=R.m(5064).exports
